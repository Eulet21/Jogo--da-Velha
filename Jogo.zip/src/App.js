import { useState } from 'react';

function Square({ value, onSquareClick }) {
  return (
    <button
      onClick={onSquareClick}
      style={{
        width: '50px',     // Largura do quadrado
        height: '50px',    // Altura do quadrado
        fontSize: '20px',   // Tamanho da fonte
        display: 'flex',    // Centralização do conteúdo
        justifyContent: 'center',
        alignItems: 'center',
        border: '1px solid #999', // Borda dos quadrados
        cursor: 'pointer'
      }}
    >
      {value}
    </button>
  );
}

// Fazendo um componente interativo 

// uma função chamada handleClick dentro de Square
// adicionei - onClick às props do elemento JSX button retornado de Square
// USESTATE - a qual você pode chamar a partir de seu componente para permitir que ele “lembre-se” de coisas

// Passando dados através de props

// Usando só VALUE, fica vazio, precisa usar  componente Board não passou a prop value a cada componente Square que ele renderiza ainda. Para consertar isso você adicionará a prop value a cada componente Square renderizado pelo componente Board
// indica que o componente Square aceita receber uma prop chamada value.
//você usará props para passar o valor que cada quadrado deve ter a partir de seu componente pai (Board) para seus filhos (Square), fazendo que não fique os números repetidos

// função antes era square, mas na verdade não é mais um quadrado, agora é board 
// função chamada Square
// Default diz aos outros arquivos usando seu código que essa é a função principal em seu arquivo
// Usar Fragments (<> e </>) para agrupar vários elementos JSX, sem isso, vai constar erro

// return qualquer coisa que venha após ela é retornada como um valor para quem chamar esta função
// className="square" é uma propriedade do botão ou prop que diz à CSS como estilizar o botão

//Construindo o tabuleiro 

function Board({ xIsNext, squares, onPlay }) {
  function handleClick(i) {
    if (calculateWinner(squares) || squares[i]) {
      return;
    }
    const nextSquares = squares.slice();
    if (xIsNext) {
      nextSquares[i] = 'X';
    } else {
      nextSquares[i] = 'O';
    }
    onPlay(nextSquares);
  }

  const winner = calculateWinner(squares);
  let status;
  if (winner) {
    status = 'Winner: ' + winner;
  } else {
    status = 'Next player: ' + (xIsNext ? 'X' : 'O');
  }

  return (
    <>
      <div style={{ marginBottom: '20px', fontSize: '20px' }}>{status}</div>
      <div style={{ display: 'flex' }}>
        <Square value={squares[0]} onSquareClick={() => handleClick(0)} />
        <Square value={squares[1]} onSquareClick={() => handleClick(1)} />
        <Square value={squares[2]} onSquareClick={() => handleClick(2)} />
      </div>
      <div style={{ display: 'flex' }}>
        <Square value={squares[3]} onSquareClick={() => handleClick(3)} />
        <Square value={squares[4]} onSquareClick={() => handleClick(4)} />
        <Square value={squares[5]} onSquareClick={() => handleClick(5)} />
      </div>
      <div style={{ display: 'flex' }}>
        <Square value={squares[6]} onSquareClick={() => handleClick(6)} />
        <Square value={squares[7]} onSquareClick={() => handleClick(7)} />
        <Square value={squares[8]} onSquareClick={() => handleClick(8)} />
      </div>
    </>
  );
}

export default function Game() {
  const [history, setHistory] = useState([Array(9).fill(null)]);
  const [currentMove, setCurrentMove] = useState(0);
  const xIsNext = currentMove % 2 === 0;
  const currentSquares = history[currentMove];

  function handlePlay(nextSquares) {
    const nextHistory = [...history.slice(0, currentMove + 1), nextSquares];
    setHistory(nextHistory);
    setCurrentMove(nextHistory.length - 1);
  }

  function jumpTo(nextMove) {
    setCurrentMove(nextMove);
  }

  const moves = history.map((squares, move) => {
    let description;
    if (move > 0) {
      description = 'Go to move #' + move;
    } else {
      description = 'Go to game start';
    }
    return (
      <li key={move}>
        <button onClick={() => jumpTo(move)}>{description}</button>
      </li>
    );
  });

  return (
    <div className="game">
      <div className="game-board">
        <Board xIsNext={xIsNext} squares={currentSquares} onPlay={handlePlay} />
      </div>
      <div className="game-info">
        <ol>{moves}</ol>
      </div>
    </div>
  );
}

function calculateWinner(squares) {
  const lines = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
  ];
  for (let i = 0; i < lines.length; i++) {
    const [a, b, c] = lines[i];
    if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
      return squares[a];
    }
  }
  return null;
}
